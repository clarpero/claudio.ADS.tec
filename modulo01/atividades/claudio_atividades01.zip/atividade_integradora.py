produto = "Caderno"
preco_unitario = 25.50
quantidade = 75
percentual_desconto = 10

subtotal = preco_unitario * quantidade
valor_desconto = subtotal * percentual_desconto/100
total = subtotal - valor_desconto

print(f"\nSubtotal: {subtotal}"
      f"\nValor do desconto: {valor_desconto}"
      f"\nTotal da compra: {total}"
      f"\nQuantidade > 0: {quantidade} {quantidade > 0}"
      f"\nTotal > 100: {total} {total > 100}"
      f"\nProduto tem 'a': {'a' in produto}"    #procuro a letra a dentro da variavel
      f"\nDesconto != None: {valor_desconto is not None}"
      )